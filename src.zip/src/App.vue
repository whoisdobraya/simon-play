<template>
  <div id="app">
    <h1>Simon plays</h1>
    <div @click="addUserStep">
      <button
        v-for="button in buttons"
        :key="button.name"
        :data-color="button.color"
        :disabled="stateOfPlay !== 'entering'"
        class="button"
        :class="[
          `button--${button.color}`,
          { active: activeButton === button.color },
        ]"
      ></button>
    </div>
    <p v-if="stateOfPlay === 'failed'">Game over!</p>
    <h2>Round: {{ round }}</h2>
    <div>
      <h2>Settings</h2>
      <label v-for="level in levels" :key="level.value" :for="level.value">
        <input
          :type="level.type"
          :name="level.value"
          :value="level.value"
          :disabled="disabledButton"
          :id="level.value"
          v-model="currentLevel"
        />
        {{ level.label }}
      </label>
    </div>
    <button type="button" @click="startPlay" :disabled="disabledButton">
      Start
    </button>
  </div>
</template>

<script>
/* eslint-disable */
import getRandomNumber from './helpers/getRandomNumber';
import { DELAY, STEP } from './helpers/variables';

export default {
  name: 'App',
  components: {},
  data() {
    return {
      round: 0,
      stateOfPlay: 'none',
      currentLevel: "easy",
      currentSpeed: 1500,
      activeButton: '',
      levels: {
        easy: { type: 'radio', label: 'Easy', value: 'easy', speed: 1500 },
        middle: { type: 'radio', label: 'Middle', value: 'middle', speed: 1000 },
        hard: { type: 'radio', label: 'Hard', value: 'hard', speed: 400 },
      },
      buttons: [
        { color: 'red', sound: 'http://www.kellyking.me/projects/simon/sounds/1.ogg' },
        { color: 'blue', sound: 'http://www.kellyking.me/projects/simon/sounds/2.ogg' },
        { color: 'yellow', sound: 'http://www.kellyking.me/projects/simon/sounds/3.ogg' },
        { color: 'green', sound: 'http://www.kellyking.me/projects/simon/sounds/4.ogg' },
      ],
      userSteps: [],
      stepsOfPlay: {
        sounds: [],
        colors: [],
      },
    };
  },
  methods: {
    startPlay() {
      this.stateOfPlay = 'preparing';
    },
    createStep() {
      const { colors, sounds } = this.stepsOfPlay;
      const maxIndex = this.buttons.length - 1;
      const random = getRandomNumber(maxIndex);
      const { color, sound } = this.buttons[random];
      colors.push(color);
      sounds.push(sound);
      this.stateOfPlay = 'playing';
    },
    playStep() {
      const { colors, sounds } = this.stepsOfPlay;
      sounds.forEach((sound, i) => {
        setTimeout(() => this.activateButton(sound, colors[i]), this.currentSpeed * (i + STEP));
      })
      setTimeout(() => this.stateOfPlay = 'entering', this.currentSpeed * sounds.length);
    },
    playSound(sound) {
      const audio = new Audio(sound);
      return audio.play();
    },
    activateButton(sound, color) {
      this.activeButton = color;
      const audio = this.playSound(sound);
      audio.then(() => setTimeout(() => this.activeButton = '', DELAY.ACTIVE_COLOR));
    },
    addUserStep({ target }) {
      const color = target.dataset.color;
      if (!color) return;
      this.userSteps.push(color);
      const { sound }  = this.buttons.filter((button) => button.color === color)[0];
      this.activateButton(sound, color);
    },
    checkUserSteps() {
      const allRight = this.userSteps.every((step, i) => step === this.stepsOfPlay.colors[i]);
      const countSteps = this.userSteps.length === this.stepsOfPlay.colors.length;
      if (!allRight) this.stateOfPlay = 'failed';
      if (allRight && !countSteps) this.stateOfPlay = 'entering';
      if (allRight && countSteps) {
        this.userSteps = [];
        this.stateOfPlay = 'preparing';
      }
    },
  },
  computed: {
    disabledButton() {
      return this.stateOfPlay !== "none" || this.stateOfPlay !== "failed";
    },
  },
  watch: {
    stateOfPlay() {
      switch(this.stateOfPlay) {
        case "preparing": {
          this.round++;
          this.createStep();
          break;
        }
        case "playing": {
          setTimeout(() => this.playStep(), DELAY.BETWEEN_ROUNDS);
          break;
        }
        case "checking": {
          this.checkUserSteps();
          break;
        }
        case "failed": {
          this.countClicks = 0;
          this.round = 0;
          this.stepsOfPlay = { colors: [], sounds: [] };
          break;
        }
      }
    },
    userSteps() {
      if (this.userSteps.length > 0) {
        this.stateOfPlay = 'checking';
      }
    },
    currentLevel() {
      this.currentSpeed = this.levels[this.currentLevel].speed;
      console.log(this.currentSpeed);
    },
  },
};
</script>

<style lang="scss">
.button {
  border: 0;
  width: 100px;
  height: 100px;
  opacity: 0.1;

  &--red {
    background-color: red;
  }
  &--blue {
    background-color: blue;
  }
  &--yellow {
    background-color: yellow;
  }
  &--green {
    background-color: green;
  }

}
  .active {
    opacity: 1;
  }

</style>
