export const DELAY = {
  BETWEEN_ROUNDS: 400,
  ACTIVE_COLOR: 250,
};

export const STEP = 1;
