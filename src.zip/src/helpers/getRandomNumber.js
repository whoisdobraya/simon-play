export default (max) => {
  return Math.round(Math.random() * max);
};
